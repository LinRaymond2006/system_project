#ifndef __REG_IRQ_H__
#define __REG_IRQ_H__

extern void SetIdtEntry();
extern void SetTssTable();

#endif