#ifndef __8259A_HANDLER_H__
#define __8259A_HANDLER_H__

#include "gpio.h"
#include "printf.h"
/*
don't forget those definitions!

//set by host system--------
.set SREG_ES, 0x00
.set SREG_DS, 0x08
.set REG_R15, 0x10
.set REG_R14, 0x18
.set REG_R13, 0x20
.set REG_R12, 0x28
.set REG_R11, 0x30
.set REG_R10, 0x38
.set REG_R9, 0x40
.set REG_R8, 0x48
.set REG_RBP, 0x50
.set REG_RDI, 0x58
.set REG_RSI, 0x60
.set REG_RDX, 0x68
.set REG_RCX, 0x70
.set REG_RBX, 0x78
.set REG_RAX, 0x80
.set HANDLER_ADDR, 0x88
//--------------------------

//set by processor----------
.set ERRCODE, 0x90
.set REG_RIP, 0x98
.set SREG_CS, 0xa0
.set CREG_RFLAGS, 0xa8
.set REG_RSP_OLD, 0xb0
.set SREG_SS_OLD, 0xb8
//--------------------------

*/

#define STORE_REGS_ASM \
    "pushq $0        \n\t"    /* error code */ \
    "pushq %%rax     \n\t"    /* handler? */   \
    "pushq %%rax     \n\t"    /* rax */        \
    "pushq %%rbx     \n\t"   \
    "pushq %%rcx     \n\t"   \
    "pushq %%rdx     \n\t"   \
    "pushq %%rsi     \n\t"   \
    "pushq %%rdi     \n\t"   \
    "pushq %%rbp     \n\t"   \
    "pushq %%r8      \n\t"   \
    "pushq %%r9      \n\t"   \
    "pushq %%r10     \n\t"   \
    "pushq %%r11     \n\t"   \
    "pushq %%r12     \n\t"   \
    "pushq %%r13     \n\t"   \
    "pushq %%r14     \n\t"   \
    "pushq %%r15     \n\t"   \
    "movq  %%ds, %%rax \n\t"     \
    "pushq %%rax  \n\t"                \
    "movq  %%es, %%rax \n\t"     \
    "pushq %%rax  \n\t"                

#define RESTORE_REGS_ASM \
    "popq %%rax"                \
    "movq  %%es, %%rax \n\t"     \
    "popq %%rax"                \
    "movq  %%ds, %%rax \n\t"     \
    "popq %%r15     \n\t"   \
    "popq %%r14     \n\t"   \
    "popq %%r13     \n\t"   \
    "popq %%r12     \n\t"   \
    "popq %%r11     \n\t"   \
    "popq %%r10     \n\t"   \
    "popq %%r9      \n\t"   \
    "popq %%r8      \n\t"   \
    "popq %%rbp     \n\t"   \
    "popq %%rdi     \n\t"   \
    "popq %%rsi     \n\t"   \
    "popq %%rdx     \n\t"   \
    "popq %%rcx     \n\t"   \
    "popq %%rbx     \n\t"   \
    "popq %%rax     \n\t"    /* rax */        \
    "addq $(0x8+0x8), %rsp   \n\t"            \
    "iretq     \n\t"                          


#define LAUNCH_8259A_ISR(IRQ, TARGET) \
    __asm__ __volatile__ (  \
        "pushq $0       \n\t"   \
        STORE_REGS_ASM          \
        "movq %%rsp, %%rdi  \n\t"     /* passed as a pointer to handler */ \
        "leaq IsrLauncher.ExitIsr(%%rip), %rax  \n\t"   \
        "pushq %%rax    \n\t"   /* return address */\
        "movq %0, %rsi  \n\t"   /* passed to handler */\
        "jmp %1"                /* since the jmp will not push the return address, the IsrLauncher.ExitIsr will be executed after handler finishes*/\
        :   \
        : "m"(IRQ), "m"(TARGET) \
        :"memory", "rdi", "rax", "rsi"  \
    );


void IrqHandler0x20_8259A(unsigned long regs,unsigned long nr)	//regs:rsp,nr
{
    printf("aaa0x20\n\n");
	out_b(0x20,0x20);
}




#endif
