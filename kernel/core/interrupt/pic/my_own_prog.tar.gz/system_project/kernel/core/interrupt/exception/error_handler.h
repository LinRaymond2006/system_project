#ifndef __ERROR_HANDLER_H__
#define __ERROR_HANDLER_H__

extern void RegisterHandlerIrq();

#endif